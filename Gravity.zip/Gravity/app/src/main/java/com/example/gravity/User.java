package com.example.gravity;

public class User {
    String name;
    int recordBench;
    int recordSquat;
    int recordDeadlift;


}
